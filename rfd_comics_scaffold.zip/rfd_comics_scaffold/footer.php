</div>
</div>
<!-- PAGE ENDS ABOVE. FOOTER STARTS BELOW -->
<footer <?php body_class( 'rfd-footer-container' ); ?>>
		<p>All content &copy; Corey Freeman <?php echo date('Y'); ?>. All Rights Reserved.</p>
</footer>
<?php wp_footer(); ?>
</body>